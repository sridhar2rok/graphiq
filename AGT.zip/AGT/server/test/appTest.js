//const sch = require('../schema/schema.js');
const chai = require('chai');
const expect = chai.expect;
const url = `http://localhost:4000`;
const request = require('supertest')(url);
const should = require('should');
describe('GraphQL', () => {

  it(' Checks for the given _id, see if we have all the property set', (done) => {
     request.post('/graphql')
     .send({ query: '{data(_id:"5e6a15d02dcd801066d6a2f0"){ID Description Panelno low}}'})
     .expect(200)
     .end((err,res) => {
         //console.log(res);
         if (err) return done(err);
         // Checks for the given _id  , if we have all the property
         res.body.data.data.should.have.property('low');
         res.body.data.data.should.have.property('ID');
         res.body.data.data.should.have.property('Panelno');
         res.body.data.data.should.have.property('Description');
         done();
       })
    })

     it('Returns total 130 entry from mongo Db check if its an array', (done) => {
      request.post('/graphql')
      .send({ query: '{datas{Description}}' })
      .expect(200)
      .end((err, res) => {
          //console.log(res);
          // res will contain array of all entries total 130 from mongo Db
          if (err) return done(err);
          res.body.data.datas.should.have.instanceof(Array);
          res.body.data.datas.should.have.instanceof(Array).and.have.length(130).which.is.instanceof(Object);
           done();
       })
   })
});

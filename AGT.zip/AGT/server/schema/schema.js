const graphql = require('graphql');
const Sensor = require('../models/edata');
const _ = require('lodash');

const { 
GraphQLObjectType, 
GraphQLString, 
GraphQLSchema,
GraphQLID,
GraphQLList,
GraphQLInt
} = graphql;

/* dummy data
var edata = [
    {
    "_id": {
        "$oid": "5e2d8f7b601e301fe4093858"
    },
    "ID": "68138",
    "Panelno": "11001",
    "Description": "1001 SN3990507007-n",
    "low": "0"
},
{
    "_id": {
        "$oid": "5e2d8f7b601e301fe4093859"
    },
    "ID": "69840",
    "Panelno": "11358",
    "Description": "1358 Avda Andalucia",
    "low": "0"
},

    { Description: 'The Colour of Magic', panelno: 'Fantasy', _id: '5', ID: '554',low :'OFF' },
    { Description: 'The Light Fantastic', panelno: 'Fantasy', _id: '6', ID: '564',low :'ON' },
];
*/

const BookType = new GraphQLObjectType({
    name: 'data',
    fields: ( ) => ({
        _id: { type: GraphQLID },
        ID: { type: GraphQLInt },
        Panelno: { type: GraphQLInt },
        Description: { type: GraphQLString },
	low: { type: GraphQLInt }
    })
});

const RootQuery = new GraphQLObjectType({
    name: 'RootQueryType',
    fields: {
        
	datas: {
            type: new GraphQLList(BookType),
            resolve(parent, args)
		{
                //return edata;
		return Sensor.find({});
		}
	 	},
	data: {
            type: BookType,
            args: { _id: { type: GraphQLID } },
            resolve(parent, args)
			{
               		 // code to get data from db / other source
            		    //   return _.find(edata, { _id: args._id });
			return Sensor.findById(args._id);  //from mongoose model
			}
		}
            }
});


const Mutation = new GraphQLObjectType({
    name: 'Mutation',
    fields: {
        addiotdata: {
            type: BookType,
            args: {
      	 	ID: { type: GraphQLInt },
       		Panelno: { type: GraphQLInt },
        	Description: { type: GraphQLString },
		low: { type: GraphQLInt }
            },
            resolve(parent, args){
                let sensor = new Sensor({
                    ID: args.ID,
                    Panelno: args.panelno,
	            Description: args.Description,
		    low: args.low			
                });
                return sensor.save();
            }
        }
    }
});

module.exports = new GraphQLSchema({
    query: RootQuery,
    mutation: Mutation
});

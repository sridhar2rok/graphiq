const graphql = require('graphql');
const Sensor = require('../models/edata');
const _ = require('lodash');

const {
GraphQLObjectType,
GraphQLString,
GraphQLSchema,
GraphQLID,
GraphQLList,
GraphQLInt
} = graphql;

var edata = [
    { Description: '311 A rwf west colony yelahanka', Panelno: '464', _id: '1', ID: '554',low :'ON' },
    { Description: 'mullerstrasse 10', Panelno: '454', _id: '2', ID: '554',low :'OFF' },
    { Description: 'Achentalstrasee 25', Panelno: '158', _id: '3', ID: '554',low :'ON' },
    { Description: 'Albert-konig-strasse 11', Panelno: '946', _id: '4', ID: '554',low :'OFF' },
    { Description: 'rosenhof 28', Panelno: '775', _id: '6', ID: '554',low :'OFF' },
    { Description: 'Am Campeon 10 ', Panelno: '358', _id: '7', ID: '554',low :'ON' },
    { Description: 'Dresdenerstrasse 87', Panelno: '658', _id: '8', ID: '564',low :'ON' }
];


const BookType = new GraphQLObjectType
({
    name: 'data',
    fields: ( ) =>
    ({
        _id: { type: GraphQLID },
        ID: { type: GraphQLInt },
        Panelno: { type: GraphQLInt },
        Description: { type: GraphQLString },
	      low: { type: GraphQLInt }
    })
});

const RootQuery = new GraphQLObjectType
({
    name: 'RootQueryType',
    fields: {
            datas: {
                    type: new GraphQLList(BookType),
                    resolve(parent, args)
		                      {
                                //return edata;
		                             return Sensor.find({});
		                      }
	 	               },
	          data: {
                    type: BookType,
                    args: { _id: { type: GraphQLID } },
                    resolve(parent, args)
			                       {
               		 // code to get data from db / other source
            		    //   return _.find(edata, { _id: args._id });
			                       return Sensor.findById(args._id);  //from mongoose model
			                        }
		              },
           local: {
                          type: BookType,
                          args: { _id: { type: GraphQLID } },
                          resolve(parent, args)
      			                       {
                     		 // code to get data from db / other source
                  		    return _.find(edata, { _id: args._id });

      			                        }
      		        }
          }
});


const Mutation = new GraphQLObjectType
({
    name: 'Mutation',
    fields:
    {
        addiotdata:
        {
            type: BookType,
            args: {
      	 	         ID: { type: GraphQLInt },
       		         Panelno: { type: GraphQLInt },
        	         Description: { type: GraphQLString },
		               low: { type: GraphQLInt }
                  },
           resolve(parent, args)
           {
                    let sensor = new Sensor({
                                           ID: args.ID,
                                           Panelno: args.Panelno,
	                                         Description: args.Description,
		                                       low: args.low
                                            });
                   return sensor.save();
            }
        }
    }
});

//const tester = new EasyGraphQLTester(schema)

module.exports = new GraphQLSchema
({
    query: RootQuery,
    mutation: Mutation
});

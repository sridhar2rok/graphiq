const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const edataSchema = new Schema({
    ID: Number,
    Panelno: Number,
    Description: String,
    low: Number
});

module.exports = mongoose.model('Sensor', edataSchema);

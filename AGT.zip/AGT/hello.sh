#! /bin/bash

echo "****************Technical Task Script********************"

echo $BASH
echo $HOME
